Simple Jquery used, along with CSS, HTML5, some algorithm from wolfram math to create the heart. I hope you like it :)
HERE IS THE LINK : 

https://tanishqcodes.github.io/Girlfriend-Birthday/
